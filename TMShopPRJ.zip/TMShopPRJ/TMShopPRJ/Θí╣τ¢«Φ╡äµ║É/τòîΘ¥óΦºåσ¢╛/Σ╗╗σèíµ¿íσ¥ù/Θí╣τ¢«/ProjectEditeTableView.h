//
//  ProjectEditeTableView.h
//  TMShopPRJ
//
//  Created by lipengpeng on 13-10-21.
//  Copyright (c) 2013年 李 鹏鹏. All rights reserved.
//

#import "TableViewModel.h"
#import "MyConnectTableView.h"
#import "ProjectEditeTableViewCell.h"

@interface ProjectEditeTableView : TableViewModel

@end
