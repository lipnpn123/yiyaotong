//
//  TableCellModel.h
//  ifudi
//
//  Created by ngc ngc on 11-6-4.
//  Copyright 2011年 ngc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GlobalDataInfo.h"
 
@class TableViewModel;

@interface TableCellModel : UITableViewCell
{
	
	 
 
}

@property(assign,nonatomic)id fatherPoint;
@property(assign,nonatomic)CGFloat totalHeight;
  
-(void)updateCellWithDictionary:(NSDictionary *)dic;
@end

