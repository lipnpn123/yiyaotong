//
//  TMShopPRJTests.h
//  TMShopPRJTests
//
//  Created by 李 碰碰 on 13-8-16.
//  Copyright (c) 2013年 李 鹏鹏. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface TMShopPRJTests : SenTestCase

@end
