//
//  PopNoticeView.h
//  TMShopPRJ
//
//  Created by 罗 乐华建 on 13-9-27.
//  Copyright (c) 2013年 李 鹏鹏. All rights reserved.
//

#import "BaseView.h"

@interface PopNoticeView : BaseView
-(void)popView:(CGPoint)point withString:(NSString *)string;

@end
