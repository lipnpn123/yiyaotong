//
//  HomePageViewController.h
//  TMShopPRJ
//
//  Created by 李 碰碰 on 13-8-19.
//  Copyright (c) 2013年 李 鹏鹏. All rights reserved.
//

#import "BaseViewController.h"
#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/WeiyunAPI.h>
#import "WXApiObject.h"
#import "WXApi.h"

#import "VRGCalendarView.h"

@interface HomePageViewController : BaseViewController<VRGCalendarViewDelegate>

@end
