//
//  WindowMacro.h
//  CBExtension
//
//  Created by ly on 13-7-1.
//  Copyright (c) 2013年 Lei Yan. All rights reserved.
//

#ifndef CBExtension_WindowMacro_h
#define CBExtension_WindowMacro_h

#define KeyWindow       [[UIApplication sharedApplication] keyWindow]
#define MainWindow      [[[UIApplication sharedApplication] delegate] window]

#endif
