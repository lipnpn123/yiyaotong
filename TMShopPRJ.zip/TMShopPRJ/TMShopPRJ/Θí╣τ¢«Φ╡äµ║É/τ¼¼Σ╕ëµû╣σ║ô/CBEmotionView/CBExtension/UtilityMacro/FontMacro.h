//
//  FontMacro.h
//  CBExtension
//
//  Created by  ly on 13-6-14.
//  Copyright (c) 2013年 Lei Yan. All rights reserved.
//

#ifndef FontMacro_h
#define FontMacro_h

#define SystemFontOfSize(size)      [UIFont systemFontOfSize:(size)]
#define BoldSystemFontOfSize(size)  [UIFont boldSystemFontOfSize:(size)]

#endif
