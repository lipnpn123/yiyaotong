//
//  WatingWindow.h
//  ifudi
//
//  Created by xmk on 11-9-17.
//  Copyright 2011 ngc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WatingWindow : UIWindow {

}
+ (WatingWindow *)newWatingWindow;
+(WatingWindow *)newPZWatingWindow;
@end
