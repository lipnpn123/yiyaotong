//
//  DataCacheDefine.h
//  ShopClient
//
//  Created by li pnpn on 12-9-24.
//  Copyright 2012 linzhou. All rights reserved.
//

//
#import "DBDataCacheManager.h"
#import "DBDataCache.h"
#import "DataCacheDefine.h"
//
/***********************************************数据库地址*****************************************************/

#define DBNAME @"Cache.db"
 
 
 

#define DBMainTable                     @"DBTestTable"

#define DBVesionType                    @"DBVesionType"
#define DBTestType                    @"DBTestType"

#define DBUserAccountType       @"DBUserAccountType"
#define DBUserAccountAndPassType       @"DBUserAccountAndPassType"
#define DBShopCarInfoType       @"DBShopCarInfoType"



#define DBMedicinalCollectTable                     @"DBMedicinalCollectTable"
#define DBYaoDianCollectType                     @"DBYaoDianCollectType"
#define DBMedicinalCollectType       @"DBMedicinalCollectType"
