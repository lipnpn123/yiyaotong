//
//  GlabalData.h
//  Yoho
//
//  Created by ncg ncg-2 on 11-9-19.
//  Copyright 2011 ncg. All rights reserved.
//

#import <UIKit/UIKit.h>

//#import "GlobalDataInfo.h"
/*
 这里只导入全局的头文件
*/ 

//工具类
#import "ToolsObject.h"
 
//全局的指针
#import "GlobalPointer.h"

//快速方法
#import "QuickMethod.h"

//导入label类
#import "FontSizeConfig.h"


//
////数据设置
 #import "GlobalConfig.h"
//
////
#import "UIViewAdditions.h"
//
//#import "UIImageView+WebCache.h"



