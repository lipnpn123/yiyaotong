//
//  ThreadMacro.h
//  CBExtension
//
//  Created by ly on 13-7-14.
//  Copyright (c) 2013年 Lei Yan. All rights reserved.
//

#ifndef CBExtension_ThreadMacro_h
#define CBExtension_ThreadMacro_h

#define IsMainThread()          [NSThread isMainThread]

#endif
