//
//  CusASIFormDataRequest.h
//  TravelPro
//
//  Created by li pnpn on 09-6-20.
//  Copyright 2009 linzhou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIFormDataRequest.h"
@interface CusASIFormDataRequest : ASIFormDataRequest
{

}


@end
