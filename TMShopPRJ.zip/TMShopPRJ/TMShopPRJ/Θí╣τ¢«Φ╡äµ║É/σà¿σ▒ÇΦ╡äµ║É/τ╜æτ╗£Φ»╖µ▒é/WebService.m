
//
//  WebService.m
//  ifudi
//
//  Created by ngc ngc on 11-6-14.
//  Copyright 2011 ngc. All rights reserved.
//

#import "WebService.h"
#import "ToolsObject.h"
#import "ASIDownloadCache.h"
#import "GlobalDataInfo.h"
#import "SBJSON.h"
#import "SVProgressHUD.h"
@implementation WebService

@synthesize delegate;
@synthesize finalURLString;
@synthesize theConnection;
@synthesize mutableparameter;
@synthesize requestMethod;

#pragma mark -
#pragma mark 初始化与销毁
-(id) init
{
    if (self = [super init])
	{
		finalURLString = [[NSMutableString alloc] initWithString:HEAD_URL_STR];
 		connectionDic = [[NSMutableDictionary alloc] init];
	}
    return self;
}

- (void)dealloc
{
	NSArray *keys =[connectionDic allKeys];
	for (NSString *str in keys)
	{
		ASIFormDataRequest *connection = [connectionDic objectForKey:str];
		[self closeConnection:connection];
	}
//	[connectionDic release];
// 	[finalURLString release];
//    self.delegate = nil;
//    self.requestMethod = nil;
//	[super dealloc];
	
}
#pragma mark -
#pragma mark 连接请求

-(NSString *)getConnection:(NSDictionary*)paramDic requestType:(int)tag
{
   return  [self getConnection:paramDic fileDic:nil requestTag:tag];
}

/*
 *带文件请求参数
 *fileDic{ value:@"文件路径" key:@"参数名"}
 */
-(NSString *)getConnection:(NSDictionary*)paramDic fileDic:(NSDictionary *)fileDic requestTag:(int)tag
{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	
	NSURL *url=[NSURL URLWithString:finalURLString];
	
	ASIFormDataRequest* connection = [[ASIFormDataRequest alloc] initWithURL:url];
	connection.delegate = self;
	connection.tag = tag;
    connection.timeOutSeconds = 30;
	NSMutableString* postData = [NSMutableString string];
	
	//循环对表单进行赋值
//	NSArray *paramArray = [paramDic allKeys];
//	for (int i=0;i<[paramArray count];i++)
//	{
//		NSString* key = [paramArray objectAtIndex:i];
//		NSString* value = [paramDic objectForKey:key];
//		[connection setPostValue:value forKey:key];
//		[postData appendFormat:@"&%@=%@",key,value];
//	}
    SBJSON *json = [[SBJSON alloc] init];
    NSString *string = [json stringWithObject:paramDic ];
    NSData *data= [string dataUsingEncoding: NSUTF8StringEncoding];
    connection.postBody = [[NSMutableData alloc] initWithData:data];
 	[connection addRequestHeader:@"Content-Type" value:@"application/json"];
//	if (fileDic)
//	{
//		NSArray *fileArray = [fileDic allKeys];
//		for (int i=0;i<[fileArray count];i++)
//		{
//			NSString* key = [fileArray objectAtIndex:i];
//			NSString* filePath = [fileDic objectForKey:key];
//			if ([[NSFileManager defaultManager] fileExistsAtPath:filePath])
//			{
//				[connection setFile:filePath forKey:key];
//			}
//			[postData appendFormat:@"&%@=%@",key,filePath];
//		}
//	}
//
 	
    if (self.requestMethod == nil)
    {
        connection.requestMethod = @"GET";
    }
    else
    {
        connection.requestMethod = self.requestMethod;
    }
	//如果已经初始化完成，就开始请求
	if (connection)
	{
        NSLog(@"开始请求:\n1. 内容为:%@\n2.文件参数为:%@\n3.连接地址为:%@\n4请求方式为%@",string,fileDic,finalURLString,connection.requestMethod);

		NSString *timeStap = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]];
		connection.keyValue = timeStap;
		[connectionDic setObject:connection forKey:timeStap];
		[connection startAsynchronous];
//		[connection release];
		return timeStap;
	}
	else
	{
		return nil;
	}
}

//asi的超时回调
-(void)timeoutCallBack:(ASIFormDataRequest *)aRequest
{
	[self closeConnection:aRequest];
}

- (void)requestStarted:(ASIFormDataRequest *)aRequest
{
    //	NSLog(@"有数据回传，数据链接成功");
    //	[aRequest performSelector:@selector(createTimeOut:) withObject:[NSNumber numberWithInt:NETWORK_POSTDATA_TIMEOUT]];
}

- (void)request:(ASIHTTPRequest *)request didReceiveResponseHeaders:(NSDictionary *)responseHeaders
{
    //	NSLog(@"didReceiveResponseHeaders");
}

#pragma mark -
#pragma mark 请求回调
/*------------连接成功-----------*/
- (void)requestFinished:(ASIFormDataRequest *)aRequest
{
	NSData *data = [aRequest responseData];
//    NSStringEncoding gbkEncoding =CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
 
    SBJSON *json = [[SBJSON alloc] init];
    NSObject *reurnObj = [json objectWithString:responseString];
    if (!reurnObj)
    {
        reurnObj = responseString;
    }
    NSLog(@"返回的字符串:%@",reurnObj);
    aRequest.returnObject = reurnObj;
    aRequest.isRequestSuccess = NO;
    if (reurnObj && [reurnObj isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *d = (NSDictionary *)reurnObj;
        if ([[d objectForKey:@"success"] intValue] == 1)
        {
            aRequest.isRequestSuccess = YES;
        }
        [SVProgressHUD showErrorWithStatus:checkNullValue([d objectForKey:@"status"])];

    }
	if ((delegate != nil) && [delegate respondsToSelector:@selector(requestFinished:)])
	{
		[delegate requestFinished:aRequest];
	}
    
    
    [self closeConnection:aRequest];
}


/*------------连接失败-----------*/
- (void)requestFailed:(ASIFormDataRequest *)aRequest
{
	NSLog(@"请求失败,返回的字符串:%@",[aRequest responseString]);
	if ((delegate != nil) && [delegate respondsToSelector:@selector(requestFailed:)])
	{
		[delegate requestFailed:aRequest];
	}
	
	[self closeConnection:aRequest];
}

/*------------关闭连接-----------*/
-(void)closeConnection:(ASIFormDataRequest *)aRequest
{
    NSConditionLock *lock= [[NSConditionLock alloc] init];
    
	[lock lock];
	ASIFormDataRequest *tempRequest = [connectionDic objectForKey:aRequest.keyValue];
	if (tempRequest)
	{
        //		[tempRequest.timeOutTimer invalidate];
        //		// 		[aRequest.timeOutTimer release];
        // 		tempRequest.timeOutTimer = nil;
		[tempRequest clearDelegatesAndCancel];
		tempRequest.delegate = nil;
        [tempRequest setUploadProgressDelegate:nil];
 		[tempRequest cancel];
		[connectionDic removeObjectForKey:tempRequest.keyValue];
		NSLog(@"连接已关闭");
        
		[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	}
	[lock unlock];
//    [lock release];
}

-(void)closeConnectionWithInfo:(NSString *)requestInfo
{
    ASIFormDataRequest *tempRequest = [connectionDic objectForKey:requestInfo];
    [self closeConnection:tempRequest];
}

//关闭所有连接
-(void)closeAllConnections
{
    for (NSString* key in [connectionDic allKeys])
	{
        ASIFormDataRequest *tempRequest = [connectionDic objectForKey:key];
        if (tempRequest)
        {
            [self closeConnection:tempRequest];
        }
    }
    NSLog(@"连接已全部关闭");
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

@end