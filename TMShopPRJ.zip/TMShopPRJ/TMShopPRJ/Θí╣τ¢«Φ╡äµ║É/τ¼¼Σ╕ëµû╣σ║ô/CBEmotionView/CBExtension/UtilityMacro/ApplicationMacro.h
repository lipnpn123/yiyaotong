//
//  ApplicationMacro.h
//  CBExtension
//
//  Created by ly on 13-7-14.
//  Copyright (c) 2013年 Lei Yan. All rights reserved.
//

#ifndef CBExtension_ApplicationMacro_h
#define CBExtension_ApplicationMacro_h

#define StatusBarOrientation()    [[UIApplication sharedApplication] statusBarOrientation]

#endif
