//
//  RootPopActionView.h
//  TMShopPRJ
//
//  Created by lipengpeng on 13-10-12.
//  Copyright (c) 2013年 李 鹏鹏. All rights reserved.
//

#import "BaseView.h"

@interface RootPopActionView : BaseView

-(void)setPopData:(UIImage *)popImage;

-(void)popView;

-(void)hidView;

@end
