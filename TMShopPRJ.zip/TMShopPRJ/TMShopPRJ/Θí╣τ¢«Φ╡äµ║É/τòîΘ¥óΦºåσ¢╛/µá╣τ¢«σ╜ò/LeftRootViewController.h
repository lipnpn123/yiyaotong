//
//  LeftRootViewController.h
//  TMShopPRJ
//
//  Created by 罗 乐华建 on 13-9-29.
//  Copyright (c) 2013年 李 鹏鹏. All rights reserved.
//

#import "BaseViewController.h"

@interface LeftRootViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate>

@end
