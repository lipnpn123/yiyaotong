//
//  CusASIFormDataRequest.m
//  TravelPro
//
//  Created by li pnpn on 09-6-20.
//  Copyright 2009 linzhou. All rights reserved.
//

#import "CusASIFormDataRequest.h"


@implementation CusASIFormDataRequest

@end
