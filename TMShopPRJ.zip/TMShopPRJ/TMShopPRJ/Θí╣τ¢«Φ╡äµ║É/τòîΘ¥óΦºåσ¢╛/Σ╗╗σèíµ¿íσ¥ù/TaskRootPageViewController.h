//
//  TaskRootPageViewController.h
//  TMShopPRJ
//
//  Created by 罗 乐华建 on 13-9-27.
//  Copyright (c) 2013年 李 鹏鹏. All rights reserved.
//

#import "BaseViewController.h"
#import "PopListView.h"

@interface TaskRootPageViewController : BaseViewController<UITextFieldDelegate,PopListViewDelegate>
@property (nonatomic,strong)NSString *projectId;
@end
