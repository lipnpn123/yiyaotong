//
//  RuntimeExtension.h
//  CBExtension
//
//  Created by  ly on 13-6-15.
//  Copyright (c) 2013年 Lei Yan. All rights reserved.
//

#ifndef Map_RuntimeExtension_h
#define Map_RuntimeExtension_h

#import "NSObject+Runtime.h"

#endif
