//
//  ProjectMainTableViewCell.h
//  TMShopPRJ
//
//  Created by lipengpeng on 13-10-22.
//  Copyright (c) 2013年 李 鹏鹏. All rights reserved.
//

#import "TableCellModel.h"

@interface ProjectMainTableViewCell : TableCellModel
@property (nonatomic,strong)UIImageView *headImageView;
@property (nonatomic,strong)UILabel *projectnameLabel;
@property (nonatomic,strong)UILabel *permissionLabel;
@property (nonatomic,strong)UIImageView *bgImageView;
@property (nonatomic,strong)UILabel *attentionLabel;



@property (nonatomic,strong)UIImageView *lineImageView;;
@end
