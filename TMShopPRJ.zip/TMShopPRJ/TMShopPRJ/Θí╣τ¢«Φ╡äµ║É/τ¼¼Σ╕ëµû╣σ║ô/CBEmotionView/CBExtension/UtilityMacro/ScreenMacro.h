//
//  ScreenMacro.h
//  CBExtension
//
//  Created by ly on 13-7-14.
//  Copyright (c) 2013年 Lei Yan. All rights reserved.
//

#ifndef CBExtension_ScreenMacro_h
#define CBExtension_ScreenMacro_h

#define ScreenScale()     [[UIScreen mainScreen] scale]

#endif
