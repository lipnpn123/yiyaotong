//
//  DeviceInfo.h
//  CBExtension
//
//  Created by ly on 13-7-7.
//  Copyright (c) 2013年 Lei Yan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeviceInfo : NSObject

+ (NSString*)IPAddress;

@end
