//
//  SinaWeiboAuthorizeView.h
//  sinaweibo_ios_sdk
//
//  Created by Wade Cheng on 4/19/12.
//  Copyright (c) 2012 SINA. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol KRShareAuthorizeViewDelegate;

@interface KRShareAuthorizeView : UIView <UIWebViewDelegate>
{
    UIWebView *webView;
    UIButton *closeButton;
    UIView *modalBackgroundView;
    UIActivityIndicatorView *indicatorView;
    UIInterfaceOrientation previousOrientation;
    
    id<KRShareAuthorizeViewDelegate> delegate;
    
    NSString *appRedirectURI;
    NSDictionary *authParams;
}

@property (nonatomic, assign) id<KRShareAuthorizeViewDelegate> delegate;

- (id)initWithAuthParams:(NSDictionary *)params
                delegate:(id<KRShareAuthorizeViewDelegate>)delegate;

- (void)show;
- (void)hide;

@end

@protocol KRShareAuthorizeViewDelegate <NSObject>

- (void)authorizeView:(KRShareAuthorizeView *)authView
        didRecieveAuthorizationCode:(NSString *)code;
- (void)authorizeView:(KRShareAuthorizeView *)authView
        didFailWithErrorInfo:(NSDictionary *)errorInfo;
- (void)authorizeViewDidCancel:(KRShareAuthorizeView *)authView;

@end