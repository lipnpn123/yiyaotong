//
//  RootTaskPopView.h
//  TMShopPRJ
//
//  Created by 罗 乐华建 on 13-9-30.
//  Copyright (c) 2013年 李 鹏鹏. All rights reserved.
//

#import "PopListView.h"


@interface RootTaskPopView : PopListView

-(void)checkDataArray:(NSArray *)array;
-(void)reloadPopViewUI;

@end
